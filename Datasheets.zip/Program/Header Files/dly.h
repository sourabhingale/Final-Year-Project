#ifndef DELAY_H
#define DELAY_H

/* Include inbuilt delay.h */
#include "includes.h"

/* Function Declarations */
void dlyms(int16u dly);
void dlyus(int16u dly);


#endif

